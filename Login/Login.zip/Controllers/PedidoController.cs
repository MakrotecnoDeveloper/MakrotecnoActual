﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.IdentityModel.Tokens;
using Plataforma.Domain.Exceptions;
using Plataforma.Models;
using Plataforma.Servicios.Contrato;
using Plataforma.Servicios.Implementacion;

namespace Plataforma.Controllers
{
    public class PedidoController : Controller
    {
        private readonly IPedidoService _pedidoServicio;
        private readonly IProductoService _productoservice;
        private readonly ITercerosService _tercerosService;
        private readonly ILogger<HomeController> _logger;
        public PedidoController(IPedidoService pedidoServicio, IProductoService productoservice, ILogger<HomeController> logger, ITercerosService tercerService)
        {
            _pedidoServicio = pedidoServicio;
            _productoservice = productoservice;
            _logger = logger;
            _tercerosService = tercerService;
        }
        public IActionResult Index()
        {
            _pedidoServicio.ActualizarEstadoFacturas();
            var facturas = _pedidoServicio.ObtenerFacturasFechaDescendente();
            return View(facturas);
        }
        [HttpGet]
        public async Task<IActionResult> CrearVenta() 
        {
            var model = new OrdenesServicioViewModel
            {
                Clientes = await _tercerosService.ObtenerClientes()
            };
            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult> CrearVenta(Ventas venta)
        {
            venta.FechaVenta = DateTime.Now;
            venta.EstadoVenta = "Pendiente";
            venta.Total = 0;
            venta.MetodoPago = "Pendiente"; // informativo

            var creada = await _pedidoServicio.CrearVentaAsync(venta);

            if (!creada)
            {
                TempData["ErrorMessage"] = "No se pudo crear la venta.";
                return RedirectToAction("CrearVenta");
            }

            return RedirectToAction("AgregarProductoAVenta", new { idVenta = venta.IdVenta });
        }

        public async Task<IActionResult> ListaVentas()
        {
            var ventas = await _pedidoServicio.ObtenerTodasLasVentasAsync(); // este método trae las ventas
            return View(ventas);
        }
        [HttpGet]
        public async Task<IActionResult> DetalleVenta(int idVenta)
        {
            var model = await _pedidoServicio.ObtenerVentaConPedidos(idVenta);

            if (model == null)
            {
                TempData["ErrorMessage"] = "La venta no existe.";
                return RedirectToAction("ListaVentas");
            }

            return View(model);
        }


        [HttpGet]
        public async Task<IActionResult> RegistrarPagos(int idVenta)
        {
            var venta = await _pedidoServicio.ObtenerVentaConDetalleAsync(idVenta);

            if (venta == null)
            {
                TempData["ErrorMessage"] = "La venta no existe.";
                return RedirectToAction("ListaVentas");
            }

            if (venta.EstadoVenta != "Confirmada")
            {
                TempData["ErrorMessage"] = "La venta debe estar confirmada para registrar pagos.";
                return RedirectToAction("DetalleVenta", new { idVenta });
            }

            var viewModel = new RegistrarPagosViewModel
            {
                IdVenta = venta.IdVenta,
                IdCliente = venta.IdCliente,
                TotalVenta = venta.Total
            };

            return PartialView("_RegistrarPagos", viewModel);
        }
        [HttpPost]
        public async Task<IActionResult> RegistrarPagos(RegistrarPagosViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // ✅ Construir método final
            var metodos = new List<string>();
            if (model.MontoEfectivo > 0) metodos.Add("Efectivo");
            if (model.MontoTransferencia > 0) metodos.Add("Transferencia");
            if (model.MontoCredito > 0) metodos.Add("Crédito");
            var metodoPagoFinal = string.Join(" + ", metodos);

            await _pedidoServicio.FacturarConPagosAsync(
                model.IdVenta,
                model.IdCliente,
                metodoPagoFinal,                 // ✅ 3er parámetro: string
                model.MontoEfectivo,             // ✅ 4to: decimal
                model.MontoTransferencia,        // ✅ 5to: decimal
                model.MontoCredito,              // ✅ 6to: decimal
                model.FechaVencimientoCredito    // ✅ 7mo: DateTime?
            );

            TempData["SuccessMessage"] = "Factura emitida correctamente.";
            return RedirectToAction("DetalleVenta", new { idVenta = model.IdVenta });
        }
        [HttpGet]
        public async Task<IActionResult> BuscarProductoPorCodigo(string codigo)
        {
            var resultado = await _pedidoServicio.BuscarProductoPorCodigoAsync(codigo);

            if (resultado == null)
                return NotFound();

            return Json(new
            {
                valorVenta = resultado.Value.valorVenta,
                valorNeto = resultado.Value.valorNeto
            });
        }
        [HttpGet]
        public async Task<IActionResult> BuscarProductoPorNombreVenta(string texto)
        {
            
                var result = await _pedidoServicio.BuscarProductosPorNombreVentaAsync(texto, User);
                return Json(result);
            
        }


        [HttpGet]
        public IActionResult AgregarProductoAVenta(int idVenta)
        {
            var viewModel = new PedidosViewModel
            {
                IdVenta = idVenta,
                Productos = new List<Pedidos>
        {
            new Pedidos() // Inicializa con una fila vacía
        }
            };

            return View(viewModel); // ✅ Ahora el modelo coincide con la vista
        }

        [HttpPost]
        public async Task<IActionResult> AgregarMultiplesProductosAVenta(PedidosViewModel model)
        {
            try
            {
                await _pedidoServicio.GuardarPedidosAsync(model.Productos, model.IdVenta, User);
                return RedirectToAction("DetalleVenta", new { idVenta = model.IdVenta });
            }
            catch (PedidoException ex)
            {
                TempData["ErrorMessage"] = ex.Message; // Pone el mensaje de error en TempData
                return RedirectToAction("Error", "Errores"); // Redirige a ErroresController
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error inesperado: {ex.Message}";
                return RedirectToAction("Error", "Errores"); // Redirige a ErroresController
            }
        }

        public IActionResult CrearFactura()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CrearFactura(int idVenta, int Iva)
        {
            var venta = await _pedidoServicio.ObtenerVentaConPedidos(idVenta);
            if (venta.Venta == null || venta.Venta.Pedidos.Count == 0)
            {
                TempData["ErrorMessage"] = "No se encontró la venta o no tiene productos.";
                return RedirectToAction("AgregarFactura");
            }
            //decimal iva = subtotal * 0.19M;
            decimal total = (decimal)venta.Venta.Pedidos.Sum(p => p.SubTotal);
            decimal totalIva = ((total * Iva) / 100);
            if (totalIva > 0)
            {
                total = totalIva + total;
            }
            await _pedidoServicio.GuardarVentaActualizada(venta.Venta, total);

            Factura factura = new Factura
            {
                NumeroFactura = "1",
                FechaEmision = DateTime.Now,
                IdVenta = idVenta,
                SubTotal = total,
                IVA = totalIva,
                Total = total,
                EstadoFactura = "Emitida"
            };

            await _pedidoServicio.GuardarFacturaAsync(factura);

            await _pedidoServicio.ActualizarEstadoVentaAsync(idVenta, "Finalizado");

            return RedirectToAction("ListaFacturas");
        }
        public async Task<IActionResult> ListaFacturas()
        {
            var facturas = await _pedidoServicio.ObtenerFacturasConVentaCliente();
            return View(facturas);
        }
        public async Task<IActionResult> DetalleFactura(int idFactura)
        {
            var factura = await _pedidoServicio.ObtenerFacturaConDetalle(idFactura);
            if (factura == null)
                return NotFound();

            return View(factura);
        }
        [HttpPost]
        public async Task<IActionResult> AnularFactura(int idFactura)
        {
            bool result = await _pedidoServicio.AnularFacturaAsync(idFactura);
            if (!result)
                TempData["ErrorMessage"] = "No se pudo anular la factura.";

            return RedirectToAction("ListaFacturas");
        }
        [HttpPost]
        public async Task<IActionResult> EliminarFactura(int idFactura)
        {
            bool eliminado = await _pedidoServicio.EliminarFacturaAsync(idFactura);
            if (!eliminado)
                TempData["ErrorMessage"] = "No se pudo eliminar la factura.";

            return RedirectToAction("ListaFacturas");
        }
        [HttpPost]
        public async Task<IActionResult> CambiarEstadoVenta(int idVenta, string nuevoEstado)
        {
            try
            {
                await _pedidoServicio.CambiarEstadoVentaAsync(idVenta, nuevoEstado);
                return RedirectToAction("DetalleVenta", new { idVenta });
            }
            catch (PedidoException ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                return RedirectToAction("Error", "Errores");
            }
        }

        [HttpGet]
        public async Task<IActionResult> BuscarFacturaPorId(int IdFactura)
        {
            var factura = await _pedidoServicio.ObtenerFacturaConAdicionesAsync(IdFactura);
            if (factura == null)
                return PartialView("_FacturaNoEncontrada");

            var rol = User.IsInRole("Administrador") ? "Admin" : "User";
            ViewBag.Rol = rol;
            return PartialView("_FacturaParcial", factura);
        }

        [HttpGet]
        public IActionResult FormularioAdicion(int IdFactura)
        {
            return PartialView("_FormularioAdicion", IdFactura);
        }

        [HttpPost]
        public async Task<IActionResult> GuardarAdicion(int IdFactura, decimal Valor, string Descripcion, string EstadoAdicion)
        {
            var cedulaClaim = User.FindFirst("Cedula")?.Value;
            if (int.TryParse(cedulaClaim, out int cedulaEmpleado))
            {
                var resultado = await _pedidoServicio.AgregarAdicionFacturaAsync(IdFactura, Valor, Descripcion, cedulaEmpleado, EstadoAdicion);
                return Json(new { success = resultado });
            }
            return Json(new { success = false });
        }
        public IActionResult VerConceptos()
        {
            //var facturas = _pedidoServicio.ObtenerFacturasFechaDescendente();
            var traerConceptos = _pedidoServicio.ObtenerConceptosCompletos();
            return View(traerConceptos);
        }
        [HttpGet]
        public async Task<IActionResult> BuscarProductoPorCodigoVenta(string codigo)
        {
            //Console.WriteLine("Me oprimiste aca" + codigo);
            var productos = await _pedidoServicio.BuscarProductosPorCodigo(codigo);
            var resultados = productos.Select(p => new {
                label = $"{p.ProductoId} - {p.Producto.NombreProducto}",
                value = p.ProductoId,
                valorNeto = p.ValorNeto,
                valorVenta = p.PrecioUnitario
            });

            return Json(resultados);
        }
        [HttpGet]
        public async Task<IActionResult> ImprimirFactura(int idFactura)
        {
            var factura = await _pedidoServicio.ObtenerFacturaConDetalle(idFactura);
            if (factura == null) return NotFound();

            return View(factura); // Vista: ImprimirFactura.cshtml
        }
    }
}
